<?php

/** @var Marinha\Mvc\ValueObjects\DocumentoPaginaVO[] $Documento */
/** @var  Marinha\Mvc\Models\Paginas[] $paginasList */

?>
<?php require_once __DIR__ . "../../topo.php" ?>
 <!-- is.min.js serve para identificar se o usuário está no Windows ou Linux -->
 <script src="../../../scripts/serpro/lib/serpro/is.min.js" type="text/javascript"></script>
  <link rel="stylesheet" href="../../../css/bootstrap.min.css">
    <script src="../../../scripts/jquery-3.1.1.slim.min.js"></script>
    <script src="../../../scripts/js/bootstrap.min.js"></script>

<!-- os próximos dois arquivos - em Javascript puro - são a API de comunicação com o Assinador SERPRO -->
<script src="../../../scripts/serpro/lib/serpro/serpro-signer-promise.js" type="text/javascript"></script>
<script src="../../../scripts/serpro/lib/serpro/serpro-signer-client.js" type="text/javascript"></script>


<!-- PDFJS, para converter bas364 em PDF -->
<script src="//mozilla.github.io/pdf.js/build/pdf.js"></script>
<div class="container">
    <div class="bg-body-tertiary rounded-3 row">
        <div class="col divisao_bottom form-control-padronizado" id="modIdxDocumento">
            <h3>Tratamento e Indexação de documento</h3>
            <div class="Grade_maior">
                <div class="container_item_maior">
                    <div class="Descricao_maior">
                        NIP
                    </div>
                    <div class="Descricao_maior">
                        Semestre
                    </div>
                    <div class="Descricao_maior">
                        Ano
                    </div>
                    <div class="Descricao_maior">
                        Tipo de documento
                    </div>
                    <div class="Descricao_maior">
                        Armário
                    </div>
                </div>
                <?php foreach ($Documento  as $documentos) : ?>
                    <div class="container_item_maior">
                        <div class="Descricao_maior">
                            <?= $documentos['nip']; ?>
                        </div>
                        <div class="Descricao_maior">
                            <?= $documentos['semestre']; ?>
                        </div>
                        <div class="Descricao_maior">
                            <?= $documentos['ano']; ?>
                        </div>
                        <div class="Descricao_maior">
                            <?= $documentos['desctipo']; ?>
                        </div>
                        <div class="Descricao_maior">
                            <?= $documentos['nomeArmario']; ?>
                        </div>

                    </div>
                <?php endforeach; ?>
            </div>
            <?php if (Count($paginasList) == 0) { ?>
                <div id="gradeOpcoes" name="gradeOpcoes" style="border: 1px #000 solid;">
                    <div style="display: inline-block;">
                        <form id="formDocImg" name="formDocImg" action="/indexar-documento-img" method="post">
                            <input type="hidden" id="idDocumento" name="idDocumento" value="<?= $documentos['id']; ?>">
                            <input type="hidden" id="IdPasta" name="IdPasta" value="<?= $documentos['idPasta']; ?>">
                            <input type="submit" class="btn btn-primary" name="btnDocImg" id="btnDocImg" value="Indexar Imagens em documentos pdf">                 
                        </form>
                    </div>
                    <div style="display: inline-block;">
                        <form id="formDocOm" name="formDocOm" action="/indexar-documento-om" method="post">
                            <input type="hidden" id="idDocumento" name="idDocumento" value="<?= $documentos['id']; ?>">
                            <input type="hidden" id="IdPasta" name="IdPasta" value="<?= $documentos['idPasta']; ?>">
                            <input type="submit" class="btn btn-primary" name="btnDocOm" id="btnDocOm" value="Indexar PDFs em documento">                 
                        </form>
                    </div>
                    <div style="display: inline-block;">
                        <form id="formDocOl" name="formDocOl" action="/indexar-documento-ol" method="post">
                            <input type="hidden" id="idDocumento" name="idDocumento" value="<?= $documentos['id']; ?>">
                            <input type="hidden" id="IdPasta" name="IdPasta" value="<?= $documentos['idPasta']; ?>">
                            <input type="submit" class="btn btn-primary" name="btnDocOl" id="btnDocOm" value="Indexar PDF Completo">                 
                        </form>
                    </div>                    
                </div>
                <!--<h3>Informe as Tags</h3>
                <form method="post" id="formIncluirPagDoc" name="formIncluirPagDoc" action="" enctype="multipart/form-data">
                    <input type="hidden" id="IdDocumento" name="IdDocumento" value="<?= $documentos['id']; ?>">
                    <input type="hidden" id="IdPasta" name="IdPasta" value="<?= $documentos['idPasta']; ?>">
                    <div class="form-row">
                        <div class="col-md-3 mb-3">
                            <label class="col-form-label" for="Assunto">Informe o assunto </label>
                            <input type="text" id="Assunto" name="Assunto" class="form-control">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="col-form-label" for="Autor">Informe o Autor </label>
                            <input type="text" id="Autor" name="Autor" class="form-control">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="col-form-label" for="Titulo">Titulo</label>
                            <input type="text" id="Titulo" name="Titulo" class="form-control">
                        </div>
                    </div>
                    <div class="form-row">
                        <h3>Incluir páginas</h3>
                        <div class="col-md-3 mb-3">
                            <label class="col-form-label" for="documento[]">Selecione as páginas</label>
                            <input type="file" id="documento[]" name="documento[]" class="form-control" multiple>
                        </div>
                        <input type="buttton" class="btn btn-primary" name="btnIncluiPag" id="btnIncluiPag" value="Incluir páginas">
                    </div>
                  
                </form>-->
            <?php } ?>
            <span class="alerta"></span>

            <?php if (Count($paginasList) > 0) { ?>
                <?php if (($paginasList[0]["flgcriptografado"] == null) || (!$paginasList[0]["flgcriptografado"])) { ?>
                    <h3><a class="abrirDocumento" data-id=<?= $documentos['id']; ?> data-cf="false">Veja o documento</a></h3>
                <?php } else { ?>
                    <h3><a class="abrirDocumento" data-id=<?= $documentos['id']; ?> data-cf="true">Veja o documento</a></h3>
                <?php } ?>
                <div class="form-row">
                    <input type="buttton" class="btn btn-primary" value="Assinar digital" />
                    <input type="buttton" class="btn btn-primary" value="Liberar documento para assinatura digital e criptografia" />
                </div>
            <?php }
            ?>
        </div>
    </div>
	<div class="row col-12">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="panel-title">Assinar PDF</h3>
          </div>
          <div class="panel-body">
            <form id="assinarPdf">
              <div class="form-group">
                <label for="file_input">Escolher Arquivo PDF</label>
                <input id="input-file" type="file" id="arquivo" name="arquivo" value="$paginasList.firstOrDefault()" onchange="convertToBase64();" />
              </div>
              <div class="form-group">
                <label for="content-value">Conteúdo do PDF (Base 64)</label>
                <textarea id="content-value" class="form-control" rows="5" disabled></textarea>
              </div>
              <div class="form-group row">
                <div class="col-sm-2">
                  <button type="submit" id="assinarPdf" name="assinarPdf" class="btn btn-primary">Assinar PDF</button>
                </div>
              </div>
              <div class="form-group">
                <label for="sign-websocket">Comando WebSocket</label>
                <textarea id="sign-websocket" class="form-control" rows="7" disabled></textarea>
              </div>
            </form>
          </div>
        </div>
      </div>
      
	  <div class="row col-12">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="panel-title">PDF Assinado</h3>
          </div>
          <div class="panel-body">
            <form>
              <div class="form-group">
                <label for="resultado">Arquivo Assinado (PDF + Assinatura em Base 64)</label>
                <textarea id="assinatura" class="form-control" rows="5" disabled></textarea>
              </div>
              <div class="form-group">
                <button id="validarAssinaturaPdf" type="button" class="btn btn-primary">Validar Assinatura</button>
                <button type="button" class="btn btn-primary" onclick="downloadPdf();">Download PDF</button>
              </div>
            </form>
          </div>
        </div>
</div>
<form method="Post" id="gradeDocumentos" name="gradeDocumentos" enctype="multipart/form-data">
    <div id="listarDocumentos" name="listarDocumentos">

    </div>
</form>

<script src="../../scripts/jquery.js"></script>
<script src="../../scripts/scripts.js"></script>
<script src="../../scripts/serpro/app/serpro-client-connector.js" type="text/javascript"></script>
    <script>
      function prettyCommandSign() {
        $('#sign-websocket').val(JSON.stringify({
          command: "sign",
          type: "pdf",
          inputData: $('#content-value').val()
        }, null, 2));
      }
      prettyCommandSign();
      
      // BASE 64
      // https://stackoverflow.com/questions/13538832/convert-pdf-to-a-base64-encoded-string-in-javascript
      function convertToBase64() {
        var selectedFile = document.getElementById("input-file").files;
        if (selectedFile.length > 0) {
          var fileToLoad = selectedFile[0];
          var fileReader = new FileReader();
          var base64;
          fileReader.onload = function(fileLoadedEvent) {
            base64 = fileLoadedEvent.target.result;
            if (base64.indexOf('data:application/pdf;base64,')==0) {
              base64 = base64.substring('data:application/pdf;base64,'.length, base64.length);
            } else {
              alert('O cabeçalho PDF não foi encontrado. Esse é mesmo um arquivo PDF?');
            }
            document.getElementById("content-value").value = base64;
            prettyCommandSign();
          };
          fileReader.readAsDataURL(fileToLoad);
        }
      }
      // Download PDF
      function downloadPdf() {
        const data = $('#assinatura').val();
        const linkSource = `data:application/pdf;base64,${data}`;
        const downloadLink = document.createElement("a");
        const fileName = "assinado.pdf";
        downloadLink.href = linkSource;
        downloadLink.download = fileName;
        downloadLink.click();
      }
    </script>